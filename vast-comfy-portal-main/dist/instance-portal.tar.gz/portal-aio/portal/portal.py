from contextlib import asynccontextmanager
from fastapi import FastAPI, Request, HTTPException, WebSocket, WebSocketDisconnect
from fastapi.templating import Jinja2Templates
from fastapi.responses import HTMLResponse, StreamingResponse, RedirectResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from typing import Optional, List
from collections import deque
import yaml
import json
import math
import httpx
import asyncio
import aiofiles
import os
import io
import re
import html as html_module
import zipfile
from datetime import datetime
import logging
import time
import ipaddress
import subprocess
import socket
import xmlrpc.client
import http.client
import GPUtil
import psutil
import sys

# Make the sibling `capabilities` package importable (portal runs with cwd
# /opt/portal-aio/portal, so its parent dir must be on sys.path).
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from capabilities import assemble_live
from capabilities.models import (
    OpenAIEndpoint,
    ProvisionRequest,
    ProvisionResponse,
    ServiceInfo,
)
import model_manager

# ANSI color maps
# Tuned for the dark log viewer background (--logs-bg ~#0b0f19).
# Standard colors (30-37) are lifted from pure CGA values so they remain
# legible on dark surfaces; bright colors (90-97) are softened to avoid glare.
_ANSI_FG_COLORS = {
    30: '#4b5563', 31: '#f87171', 32: '#4ade80', 33: '#fbbf24', 34: '#60a5fa', 35: '#c084fc', 36: '#22d3ee', 37: '#d1d5db',
    90: '#9ca3af', 91: '#fca5a5', 92: '#86efac', 93: '#fde68a', 94: '#93bbfd', 95: '#d8b4fe', 96: '#67e8f9', 97: '#f3f4f6',
}
_ANSI_BG_COLORS = {
    40: '#1f2937', 41: '#991b1b', 42: '#166534', 43: '#92400e', 44: '#1e3a5f', 45: '#6b21a8', 46: '#155e75', 47: '#4b5563',
    100: '#374151', 101: '#f87171', 102: '#4ade80', 103: '#fbbf24', 104: '#60a5fa', 105: '#c084fc', 106: '#22d3ee', 107: '#e5e7eb',
}

# Regex to strip C0/C1 control characters except tab (\x09).
# \r and \n are already consumed by _process_chunk before text reaches here.
_CONTROL_CHAR_RE = re.compile(r'[\x00-\x08\x0b-\x0d\x0e-\x1a\x7f]')

# Strip cursor movement, erase, and other non-SGR CSI sequences.
# These are interpreted by _process_chunk(); they must not appear in HTML.
_CSI_NON_SGR_RE = re.compile(r'\x1b\[\??[0-9;]*[A-Za-ln-z]')

# Tokenizer for _process_chunk: splits on ANSI CSI sequences (including
# DEC private-mode sequences like \x1b[?25l), \r\n, \r, \n
_CHUNK_TOKEN_RE = re.compile(r'(\x1b\[\??[0-9;]*[A-Za-z]|\r\n|\r|\n)')

def ansi_to_html(text: str) -> str:
    """Convert ANSI escape codes to HTML spans. HTML-escapes text content.
    Strips stray control characters (SI, SO, BEL, etc.) that are invisible
    in a real terminal but render as garbage in HTML."""
    # Strip non-SGR CSI sequences (cursor movement, erase, etc.)
    text = _CSI_NON_SGR_RE.sub('', text)
    # Split on ANSI sequences, escape text parts, convert codes to spans
    parts = re.split(r'(\x1b\[[0-9;]*m)', text)
    result = []
    open_spans = 0
    for part in parts:
        m = re.match(r'\x1b\[([0-9;]*)m', part)
        if m:
            codes = [int(c) for c in m.group(1).split(';') if c] if m.group(1) else [0]
            for code in codes:
                if code == 0:
                    result.append('</span>' * open_spans)
                    open_spans = 0
                elif code == 1:
                    result.append('<span style="font-weight:bold">')
                    open_spans += 1
                elif code == 2:
                    result.append('<span style="opacity:0.7">')
                    open_spans += 1
                elif code in _ANSI_FG_COLORS:
                    result.append(f'<span style="color:{_ANSI_FG_COLORS[code]}">')
                    open_spans += 1
                elif code in _ANSI_BG_COLORS:
                    result.append(f'<span style="background-color:{_ANSI_BG_COLORS[code]}">')
                    open_spans += 1
                # Unknown codes: silently ignored
        else:
            cleaned = _CONTROL_CHAR_RE.sub('', part)
            result.append(html_module.escape(cleaned))
    result.append('</span>' * open_spans)
    return ''.join(result)

# Configure logging
logging.basicConfig(level=logging.INFO,
                   format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger("log_monitor")

# Suppress noisy request logs (httpx at module load, uvicorn.access in lifespan
# after uvicorn has configured its loggers)
logging.getLogger("httpx").setLevel(logging.WARNING)

tunnel_manager=os.environ.get("TUNNEL_MANAGER", "http://localhost:11112")


@asynccontextmanager
async def lifespan(app):
    # Startup
    # Suppress uvicorn access logs (must be done here, after uvicorn configures its loggers)
    logging.getLogger("uvicorn.access").setLevel(logging.WARNING)
    # Prime psutil CPU counter so first real poll returns a meaningful value
    psutil.cpu_percent(interval=None)
    app.state.monitor_task = asyncio.create_task(
        monitor_log_directory("/var/log/portal")
    )
    yield
    # Shutdown
    model_manager.manager.shutdown()
    if hasattr(app.state, 'monitor_task'):
        app.state.monitor_task.cancel()
        try:
            await app.state.monitor_task
        except asyncio.CancelledError:
            pass

app = FastAPI(
    lifespan=lifespan,
    title="Vast Instance Portal",
    version="1.0.0",
    description=(
        "Management and capability-discovery API for a Vast.ai instance. "
        "GET /capabilities returns a machine-readable manifest of installed tools, "
        "python environments, hardware, running services (with their externally "
        "reachable URLs and OpenAI /v1 endpoints), provisioning, and the auth model. "
        "All routes sit behind the Caddy auth edge for remote callers; localhost "
        "callers inside the container need no token."
    ),
)

app.mount("/static", StaticFiles(directory="static"), name="static")
app.include_router(model_manager.router)
templates = Jinja2Templates(directory="templates")

def get_scheme() -> str:
    if os.environ.get("ENABLE_HTTPS", "false").lower() != "true":
        scheme = "http"
    else:
        scheme = "https"
    return scheme

def load_config() -> dict:
    yaml_path = '/etc/portal.yaml'
    
    # Wait until the file exists - caddy-manager handles config writing
    while not os.path.exists(yaml_path):
        print(f"Waiting for {yaml_path} to appear...")
        time.sleep(1)

    with open(yaml_path, 'r') as file:
        data = yaml.safe_load(file) or {}
        config_applications = data.get('applications', {})
        return hydrate_applications(config_applications)

def hydrate_applications(applications: dict) -> dict:
    # External ports that Caddy actually proxies (internal port differs from
    # external). For these Caddy owns the listener and its scheme follows
    # ENABLE_HTTPS. Must stay in sync with the tunnel manager's hydration so
    # target_url values match for tunnel lookups.
    proxied_external_ports = {
        app["external_port"]
        for app in applications.values()
        if app["external_port"] != app["internal_port"]
    }
    for app_name, app in applications.items():
        hostname = app["hostname"]
        external_port = app["external_port"]
        internal_port = app["internal_port"]
        # A straight-through :8080 entry is direct TLS (launch-mode Jupyter)
        # only when nothing else proxies :8080; in supervisor mode Caddy owns
        # the :8080 listener and the scheme follows ENABLE_HTTPS.
        if external_port == internal_port and internal_port == 8080 and 8080 not in proxied_external_ports:
            scheme = "https"
        else:
            scheme = get_scheme()
        applications[app_name]["target_url"] = f'{scheme}://{hostname}:{external_port}'
        applications[app_name]["mapped_port"] = os.environ.get(f'VAST_TCP_PORT_{external_port}', "")
    return applications

def strip_port(host: str) -> str:
    return host.split(':')[0]

_PORTAL_LINKS_YAML = "/etc/portal-links.yaml"

def _parse_yaml_link(item: dict) -> dict | None:
    """Parse a single link entry from the YAML file."""
    if not isinstance(item, dict) or not item.get("label") or not item.get("url"):
        return None
    link = {
        "label": str(item["label"]),
        "url": str(item["url"]),
        "description": str(item.get("description", "")),
        "icon": str(item.get("icon", "link")),
        "button_text": str(item.get("button_text", "Open")),
        "position": str(item.get("position", "after")),
        "links": [],
    }
    for extra in item.get("links", []) or []:
        if isinstance(extra, dict) and extra.get("label") and extra.get("url"):
            link["links"].append({
                "label": str(extra["label"]),
                "url": str(extra["url"]),
            })
    return link

def get_extra_links() -> dict:
    """Build before/after extra-links from the YAML file and env var overlay.

    1. ``/etc/portal-links.yaml`` — baked into the image at build time.
       Derivative images drop their own version via ``COPY ./ROOT /``;
       the portal update script never touches this path so it is safe.
       Supports ``icon``, ``button_text``, ``links`` (secondary buttons),
       and ``position`` (``before`` or ``after`` the built-in cards).
    2. ``PORTAL_LINKS`` env var — ``Label|URL|Description,...`` entries
       always appended after built-in cards (description is optional).

    Returns ``{"before": [...], "after": [...]}``.
    """
    before: list[dict] = []
    after: list[dict] = []

    # --- YAML defaults ---
    if os.path.isfile(_PORTAL_LINKS_YAML):
        try:
            with open(_PORTAL_LINKS_YAML, "r") as f:
                data = yaml.safe_load(f)
            for item in (data or []):
                link = _parse_yaml_link(item)
                if link:
                    if link["position"] == "before":
                        before.append(link)
                    else:
                        after.append(link)
        except Exception as e:
            print(f"WARNING: Failed to parse {_PORTAL_LINKS_YAML}: {e}")

    # --- Environment overlay (always appended after) ---
    raw = os.environ.get("PORTAL_LINKS", "").strip()
    if raw:
        for entry in raw.split(","):
            parts = entry.strip().split("|", 2)
            if len(parts) >= 2 and parts[0].strip() and parts[1].strip():
                after.append({
                    "label": parts[0].strip(),
                    "url": parts[1].strip(),
                    "description": parts[2].strip() if len(parts) > 2 else "",
                    "icon": "link",
                    "button_text": "Open",
                    "links": [],
                })

    return {"before": before, "after": after}

def get_instance_properties() -> dict:
    return {
        "id": os.environ.get("CONTAINER_ID",""),
        "gpu": get_gpu_info(),
        "direct_https": "true" if os.environ.get("ENABLE_HTTPS", "false").lower() == "true" else "false"
    }

def get_gpu_info() -> str:
    """Get formatted GPU information for both NVIDIA and AMD GPUs"""
    gpu_models = {}
    
    # Try to get NVIDIA GPUs
    try:
        nvidia_gpus = GPUtil.getGPUs()
        for gpu in nvidia_gpus:
            if gpu.name in gpu_models:
                gpu_models[gpu.name] += 1
            else:
                gpu_models[gpu.name] = 1
    except Exception:
        pass
    
    # Try to get AMD GPUs
    try:
        rocm_gpus = get_rocm_gpus()
        for gpu in rocm_gpus:
            if gpu.name in gpu_models:
                gpu_models[gpu.name] += 1
            else:
                gpu_models[gpu.name] = 1
    except Exception:
        pass
    
    # Check if any GPUs are available
    if not gpu_models:
        return "No GPU detected"
    
    # Format the output
    result = []
    for name, count in gpu_models.items():
        if count > 1:
            result.append(f"{count}× {name}")
        else:
            result.append(name)
    
    return ", ".join(result)

def get_rocm_gpus() -> list:
    """Get AMD GPU information using rocm-smi command line tool"""
    try:
        # Check if rocm-smi is available
        rocm_available = subprocess.run(
            ['which', 'rocm-smi'], 
            stdout=subprocess.PIPE, 
            stderr=subprocess.PIPE
        ).returncode == 0
        
        if not rocm_available:
            return []
        
        # First get GPU info with memory and usage
        result = subprocess.run(
            ['rocm-smi', '--showmeminfo', 'vram', '--showuse', '--json'], 
            stdout=subprocess.PIPE, 
            stderr=subprocess.PIPE, 
            text=True
        )
        
        if result.returncode != 0:
            return []
        
        # Parse JSON output for memory and usage
        rocm_data = json.loads(result.stdout)
        
        # Get additional GPU info including name
        name_result = subprocess.run(
            ['rocm-smi', '--showproductname', '--json'], 
            stdout=subprocess.PIPE, 
            stderr=subprocess.PIPE, 
            text=True
        )
        
        # Parse GPU name data if available
        gpu_names = {}
        if name_result.returncode == 0:
            try:
                name_data = json.loads(name_result.stdout)
                for card_id, card_data in name_data.items():
                    if isinstance(card_data, dict):
                        # Try to construct a meaningful name from available fields
                        vendor = card_data.get('Card Vendor', '').split('[')[-1].split(']')[0] if '[' in card_data.get('Card Vendor', '') else card_data.get('Card Vendor', '')
                        sku = card_data.get('Card SKU', '')
                        gfx = card_data.get('GFX Version', '')
                        
                        if vendor and sku:
                            gpu_names[card_id] = f"{vendor} {sku} ({gfx})"
                        elif vendor:
                            gpu_names[card_id] = f"{vendor} GPU"
                        else:
                            gpu_names[card_id] = "AMD GPU"
            except Exception:
                pass

        gpus = []
        
        for card_id, card_data in rocm_data.items():
            if not isinstance(card_data, dict):
                continue
                
            # Create a GPU object similar to GPUtil's structure
            gpu = type('', (), {})()
            gpu.id = int(card_id.replace('card', ''))
            
            # Set GPU name from the name data if available, otherwise use a default
            gpu.name = gpu_names.get(card_id, 'AMD GPU')
            
            # Extract memory info based on the actual output format
            gpu.memoryTotal = int(card_data.get('VRAM Total Memory (B)', 0))
            gpu.memoryTotal_mb = round(gpu.memoryTotal / (1024 * 1024), 2)  # Convert to MB
            
            gpu.memoryUsed = int(card_data.get('VRAM Total Used Memory (B)', 0))
            gpu.memoryUsed_mb = round(gpu.memoryUsed / (1024 * 1024), 2)  # Convert to MB
            
            # Extract GPU utilization
            gpu_busy = card_data.get('GPU use (%)', 0)
            try:
                gpu.load = float(gpu_busy) / 100.0 if isinstance(gpu_busy, (int, float, str)) else 0
            except (ValueError, TypeError):
                gpu.load = 0
                
            gpus.append(gpu)
            
        return gpus
    except Exception as e:
        print(f"Error getting ROCm GPU info: {str(e)}")
        return []
    
def is_in_container() -> bool:
    """Check if we're running inside a container"""
    return os.path.exists('/sys/fs/cgroup/memory/memory.limit_in_bytes') or os.path.exists('/sys/fs/cgroup/memory.max')

def get_container_memory_limit() -> Optional[int]:
    """Get memory limit allocated to the container.

    Prefers the soft limit (memory.soft_limit_in_bytes / memory.low) when
    set, as platforms like Vast.ai use the soft limit for the user's actual
    RAM allocation while setting a much higher hard limit that includes
    swap headroom.

    Returns None when the limit looks like 'no real limit' — either the
    sentinel value ``max`` (v2) or a value larger than the host's physical
    RAM.
    """
    try:
        host_ram = psutil.virtual_memory().total
    except Exception:
        host_ram = 0

    def _is_real_limit(value: int) -> bool:
        if value <= 0 or value >= 10**15:
            return False
        if host_ram and value >= host_ram:
            return False
        return True

    # --- cgroups v1 ---
    # Try soft limit first (the user's actual allocation on Vast.ai)
    try:
        with open('/sys/fs/cgroup/memory/memory.soft_limit_in_bytes', 'r') as f:
            soft = int(f.read().strip())
            if _is_real_limit(soft):
                return soft
    except Exception:
        pass

    try:
        with open('/sys/fs/cgroup/memory/memory.limit_in_bytes', 'r') as f:
            limit = int(f.read().strip())
            if _is_real_limit(limit):
                return limit
    except Exception:
        pass

    # --- cgroups v2 ---
    # Try memory.low (soft) first, then memory.max (hard)
    for path in ('/sys/fs/cgroup/memory.low', '/sys/fs/cgroup/memory.max'):
        try:
            with open(path, 'r') as f:
                value = f.read().strip()
                if value in ('max', '0'):
                    continue
                limit = int(value)
                if _is_real_limit(limit):
                    return limit
        except Exception:
            pass

    return None

def get_container_memory_usage() -> Optional[int]:
    """Get current memory usage of the container"""
    try:
        # cgroups v1
        with open('/sys/fs/cgroup/memory/memory.usage_in_bytes', 'r') as f:
            return int(f.read().strip())
    except Exception:
        try:
            # cgroups v2
            with open('/sys/fs/cgroup/memory.current', 'r') as f:
                return int(f.read().strip())
        except Exception:
            return None

def get_container_memory_stats() -> Optional[dict]:
    """Get detailed memory stats for container including total, used and percentage"""
    if not is_in_container():
        # Not in a container, return None to fall back to psutil
        return None
        
    limit = get_container_memory_limit()
    usage = get_container_memory_usage()
    
    if limit is None or usage is None:
        return None
        
    # Calculate percentage
    percent = (usage / limit) * 100
    
    return {
        'total': limit,
        'used': usage,
        'percent': percent
    }


# --- CPU metrics ---

# State for delta-based CPU measurement (cgroups)
_cpu_prev: dict = {'timestamp': 0.0, 'usage': 0, 'percent': 0.0}

def get_cpu_quota_cores() -> float:
    """Get the CPU quota in fractional cores from cgroups (for % normalization).
    Returns the quota as a float (e.g. 19.2), or falls back to os.cpu_count()."""
    try:
        # cgroups v2: cpu.max → "quota period"
        with open('/sys/fs/cgroup/cpu.max', 'r') as f:
            parts = f.read().strip().split()
            if parts[0] != 'max':
                return max(0.01, int(parts[0]) / int(parts[1]))
    except Exception:
        pass
    try:
        # cgroups v1: cpu.cfs_quota_us / cpu.cfs_period_us
        for prefix in ('/sys/fs/cgroup/cpu/', '/sys/fs/cgroup/cpu,cpuacct/'):
            quota_path = prefix + 'cpu.cfs_quota_us'
            period_path = prefix + 'cpu.cfs_period_us'
            if os.path.exists(quota_path):
                with open(quota_path, 'r') as f:
                    quota = int(f.read().strip())
                if quota == -1:
                    break  # no limit
                with open(period_path, 'r') as f:
                    period = int(f.read().strip())
                return max(0.01, quota / period)
    except Exception:
        pass
    return float(os.cpu_count() or 1)


def get_container_cpu_usage() -> Optional[dict]:
    """Get CPU usage for the container using cgroups delta measurement."""
    global _cpu_prev

    now = time.monotonic()
    usage_ns = None

    # cgroups v2: cpu.stat contains usage_usec
    try:
        with open('/sys/fs/cgroup/cpu.stat', 'r') as f:
            for line in f:
                if line.startswith('usage_usec'):
                    usage_ns = int(line.split()[1]) * 1000
                    break
    except Exception:
        pass

    # cgroups v1: cpuacct.usage in nanoseconds
    if usage_ns is None:
        for prefix in ('/sys/fs/cgroup/cpuacct/', '/sys/fs/cgroup/cpu,cpuacct/'):
            path = prefix + 'cpuacct.usage'
            try:
                with open(path, 'r') as f:
                    usage_ns = int(f.read().strip())
                break
            except Exception:
                continue

    if usage_ns is None:
        return None

    # Use quota (fractional cores) for both % normalization and the
    # user-visible core count.  os.cpu_count() reports the host's total
    # cores which is misleading inside a container with a CPU quota.
    quota_cores = get_cpu_quota_cores()

    elapsed = now - _cpu_prev['timestamp']
    if _cpu_prev['timestamp'] > 0 and elapsed > 0.5:
        delta_usage = usage_ns - _cpu_prev['usage']
        delta_time_ns = elapsed * 1e9
        percent = (delta_usage / delta_time_ns) * 100.0 / quota_cores
        _cpu_prev['percent'] = max(0.0, min(percent, 100.0))

    _cpu_prev['timestamp'] = now
    _cpu_prev['usage'] = usage_ns

    return {
        'percent': round(_cpu_prev['percent'], 1),
        'count': int(quota_cores)
    }


def get_cpu_stats() -> dict:
    """Get CPU usage, preferring container cgroup metrics when available."""
    if is_in_container():
        container_cpu = get_container_cpu_usage()
        if container_cpu is not None:
            return container_cpu
    # VM / host fallback
    return {
        'percent': psutil.cpu_percent(interval=None),
        'count': psutil.cpu_count() or 1
    }


# --- Workspace volume metrics ---

def get_workspace_volume_info() -> Optional[dict]:
    """Get disk usage for $WORKSPACE, only if it's on a separate mounted volume."""
    workspace = os.environ.get('WORKSPACE')
    if not workspace or not os.path.isdir(workspace):
        return None
    try:
        # Different st_dev means a separate filesystem / mount
        if os.stat('/').st_dev == os.stat(workspace).st_dev:
            return None
        usage = psutil.disk_usage(workspace)
        return {
            'path': workspace,
            'total': usage.total,
            'used': usage.used,
            'percent': usage.percent
        }
    except Exception:
        return None


templates.env.filters["strip_port"] = strip_port

tunnels = {}
tunnel_api_timeout=httpx.Timeout(connect=5.0, read=30.0, write=5.0, pool=5.0)

@app.get("/", response_class=HTMLResponse)
async def read_root(request: Request, token: Optional[str] = None) -> HTMLResponse:
    if token is not None:
        return RedirectResponse(url="/", status_code=302)

    await set_external_ip(request.headers.get("X-Forwarded-Host"))
    return templates.TemplateResponse(request, "index.html", {
        "instance": get_instance_properties(),
        "extra_links": get_extra_links(),  # {"before": [...], "after": [...]}
        })

@app.get("/health")
async def health_check() -> JSONResponse:
    return JSONResponse({"status": "ok"})

@app.get("/get-applications")
async def get_applications(request: Request) -> JSONResponse:
    applications = load_config()
    auth_token = request.cookies.get(f"" + os.environ.get('VAST_CONTAINERLABEL') + "_auth_token")
    for app_name, app in applications.items():
        separator = '&' if '?' in app["open_path"] else '?'
        app["open_path"] += f"{separator}token={auth_token}"

    return JSONResponse(applications)

async def _tunnel_proxy(method: str, path: str):
    """Proxy a request to the tunnel manager service."""
    url = f"{tunnel_manager}{path}"
    async with httpx.AsyncClient(timeout=tunnel_api_timeout) as client:
        if method == "GET":
            response = await client.get(url)
        else:
            response = await client.post(url)
        response.raise_for_status()
        return response.json()

@app.get("/get-direct-url/{port}")
async def get_direct_url(port: int):
    try:
        result = await _tunnel_proxy("GET", f"/get-direct-url/{port}")
        return result
    except httpx.HTTPStatusError as e:
        if e.response.status_code == 404:
            raise HTTPException(status_code=404, detail="Direct URL unavailable")
        raise HTTPException(status_code=e.response.status_code, detail="Tunnel manager error")
    except httpx.HTTPError:
        raise HTTPException(status_code=500, detail="Error communicating with the API")
    except Exception:
        raise HTTPException(status_code=500, detail="Unhandled error response from API")

@app.get("/get-existing-quick-tunnel/{target_url:path}")
async def get_existing_quick_tunnel(target_url: str):
    try:
        result = await _tunnel_proxy("GET", f"/get-quick-tunnel-if-exists/{target_url}")
        return HTMLResponse(result['tunnel_url'])
    except httpx.HTTPStatusError as e:
        if e.response.status_code == 404:
            raise HTTPException(status_code=404, detail="Tunnel not found")
        raise HTTPException(status_code=e.response.status_code, detail="Tunnel manager error")
    except httpx.HTTPError:
        raise HTTPException(status_code=500, detail="Error communicating with the API")
    except Exception:
        raise HTTPException(status_code=500, detail="Unhandled error response from API")

@app.get("/get-existing-named-tunnel/{port}")
async def get_existing_named_tunnel(port: int):
    try:
        result = await _tunnel_proxy("GET", f"/get-named-tunnel/{port}")
        return HTMLResponse(result['tunnel_url'])
    except httpx.HTTPStatusError as e:
        if e.response.status_code == 404:
            raise HTTPException(status_code=404, detail="Tunnel not found")
        raise HTTPException(status_code=e.response.status_code, detail="Tunnel manager error")
    except httpx.HTTPError:
        raise HTTPException(status_code=500, detail="Error communicating with the API")
    except Exception:
        raise HTTPException(status_code=500, detail="Unhandled error response from API")

@app.get("/get-all-quick-tunnels")
async def get_all_quick_tunnels():
    try:
        result = await _tunnel_proxy("GET", "/get-all-quick-tunnels")
        return result
    except httpx.HTTPStatusError as e:
        if e.response.status_code == 404:
            raise HTTPException(status_code=404, detail="Tunnel not found")
        raise HTTPException(status_code=e.response.status_code, detail="Tunnel manager error")
    except httpx.HTTPError:
        raise HTTPException(status_code=500, detail="Error communicating with the API")
    except Exception:
        raise HTTPException(status_code=500, detail="Unhandled error response from API")

@app.get("/get-named-tunnels")
async def get_named_tunnels():
    try:
        result = await _tunnel_proxy("GET", "/get-named-tunnels")
        return result
    except httpx.HTTPStatusError as e:
        if e.response.status_code in [404, 500]:
            raise HTTPException(status_code=404, detail="Tunnel config not found")
        raise HTTPException(status_code=e.response.status_code, detail="Tunnel manager error")
    except httpx.HTTPError:
        raise HTTPException(status_code=500, detail="Error communicating with the API")
    except Exception:
        raise HTTPException(status_code=500, detail="Unhandled error response from API")

@app.post("/start-quick-tunnel/{target_url:path}")
async def start_quick_tunnel(target_url: str):
    try:
        result = await _tunnel_proxy("GET", f"/get-quick-tunnel/{target_url}")
        return result
    except httpx.HTTPStatusError as e:
        if e.response.status_code == 404:
            raise HTTPException(status_code=404, detail="Tunnel not found")
        raise HTTPException(status_code=e.response.status_code, detail="Tunnel manager error")
    except httpx.HTTPError:
        raise HTTPException(status_code=500, detail="Error communicating with the API")
    except Exception:
        raise HTTPException(status_code=500, detail="Unhandled error response from API")

@app.post("/stop-quick-tunnel/{target_url:path}")
async def stop_quick_tunnel(target_url: str):
    try:
        result = await _tunnel_proxy("POST", f"/stop-quick-tunnel/{target_url}")
        return result
    except httpx.HTTPStatusError as e:
        if e.response.status_code == 404:
            raise HTTPException(status_code=404, detail="Tunnel not found")
        raise HTTPException(status_code=e.response.status_code, detail="Tunnel manager error")
    except httpx.HTTPError:
        raise HTTPException(status_code=500, detail="Error communicating with the API")
    except Exception:
        raise HTTPException(status_code=500, detail="Unhandled error response from API")

@app.post("/refresh-quick-tunnel/{target_url:path}")
async def refresh_quick_tunnel(target_url: str):
    try:
        result = await _tunnel_proxy("POST", f"/refresh-quick-tunnel/{target_url}")
        return result
    except httpx.HTTPStatusError as e:
        if e.response.status_code == 404:
            raise HTTPException(status_code=404, detail="Tunnel not found")
        raise HTTPException(status_code=e.response.status_code, detail="Tunnel manager error")
    except httpx.HTTPError:
        raise HTTPException(status_code=500, detail="Error communicating with the API")
    except Exception:
        raise HTTPException(status_code=500, detail="Unhandled error response from API")

## Supervisor process management via XML-RPC

SUPERVISOR_SOCK = "/var/run/supervisor.sock"
_unstoppable_env = os.environ.get("PORTAL_UNSTOPPABLE", "")
UNSTOPPABLE_PROCESSES = frozenset(
    {"instance_portal", "caddy", "tunnel_manager"} | {s.strip() for s in _unstoppable_env.split(",") if s.strip()}
)

class _UnixStreamHTTPConnection(http.client.HTTPConnection):
    """HTTP connection over a Unix domain socket."""
    def connect(self):
        self.sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        self.sock.connect(SUPERVISOR_SOCK)

class _UnixStreamTransport(xmlrpc.client.Transport):
    def make_connection(self, host):
        return _UnixStreamHTTPConnection(host)

def _get_supervisor_proxy() -> xmlrpc.client.ServerProxy:
    return xmlrpc.client.ServerProxy(
        "http://localhost",
        transport=_UnixStreamTransport(),
    )

def _is_launch_managed() -> bool:
    """Check if /.launch exists (Vast manages jupyter directly)."""
    return os.path.isfile("/.launch")

async def _collect_supervisor() -> list:
    """Collect supervisor process info. Shared by the route and the manifest."""
    proxy = _get_supervisor_proxy()
    all_info = await asyncio.to_thread(proxy.supervisor.getAllProcessInfo)
    launch_managed = _is_launch_managed()
    result = []
    for proc in all_info:
        # Hide jupyter when /.launch is present (Vast manages it directly)
        if launch_managed and proc["name"] == "jupyter":
            continue
        # Hide processes that skipped startup (not in portal.yaml)
        skip_marker = f"/tmp/supervisor-skip/{proc['name']}"
        if os.path.isfile(skip_marker):
            continue
        result.append({
            "name": proc["name"],
            "group": proc["group"],
            "state": proc["statename"],
            "description": proc.get("description", ""),
            "pid": proc.get("pid", 0),
            "start": proc.get("start", 0),
            "now": proc.get("now", 0),
            "unstoppable": proc["name"] in UNSTOPPABLE_PROCESSES,
        })
    return result

@app.get("/supervisor/processes")
async def get_supervisor_processes():
    try:
        return await _collect_supervisor()
    except Exception as e:
        logger.error(f"Failed to get supervisor processes: {e}")
        raise HTTPException(status_code=500, detail="Failed to communicate with supervisor")

@app.post("/supervisor/process/{name}/start")
async def supervisor_start_process(name: str):
    try:
        proxy = _get_supervisor_proxy()
        await asyncio.to_thread(proxy.supervisor.startProcess, name)
        return {"status": "ok", "name": name, "action": "start"}
    except xmlrpc.client.Fault as e:
        raise HTTPException(status_code=400, detail=e.faultString)
    except Exception as e:
        logger.error(f"Failed to start process {name}: {e}")
        raise HTTPException(status_code=500, detail="Failed to communicate with supervisor")

@app.post("/supervisor/process/{name}/stop")
async def supervisor_stop_process(name: str):
    if name in UNSTOPPABLE_PROCESSES:
        raise HTTPException(status_code=403, detail=f"Process '{name}' cannot be stopped")
    try:
        proxy = _get_supervisor_proxy()
        await asyncio.to_thread(proxy.supervisor.stopProcess, name)
        return {"status": "ok", "name": name, "action": "stop"}
    except xmlrpc.client.Fault as e:
        raise HTTPException(status_code=400, detail=e.faultString)
    except Exception as e:
        logger.error(f"Failed to stop process {name}: {e}")
        raise HTTPException(status_code=500, detail="Failed to communicate with supervisor")

@app.post("/supervisor/process/{name}/restart")
async def supervisor_restart_process(name: str):
    try:
        proxy = _get_supervisor_proxy()
        # Check the process exists first
        all_info = await asyncio.to_thread(proxy.supervisor.getAllProcessInfo)
        if not any(p["name"] == name for p in all_info):
            raise HTTPException(status_code=404, detail=f"Process '{name}' not found")

        # Use supervisorctl restart in a fully detached subprocess.
        # This is critical for self-restart (instance_portal): the XML-RPC
        # stop+start approach fails because stopping the portal kills this
        # very process before startProcess can execute.
        # start_new_session=True puts the child in its own process group so
        # it survives killasgroup=true in the supervisor config.
        subprocess.Popen(
            ["supervisorctl", "restart", name],
            start_new_session=True,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        return {"status": "ok", "name": name, "action": "restart"}
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to restart process {name}: {e}")
        raise HTTPException(status_code=500, detail="Failed to communicate with supervisor")


async def set_external_ip(forwarded_host: Optional[str]) -> None:
    if not forwarded_host:
        return
    try:
        ip, port = forwarded_host.split(":")
        ipaddress.IPv4Address(ip)  # validate
        if port != os.environ.get("VAST_TCP_PORT_1111"):
            return
        async with httpx.AsyncClient() as client:
            await client.put(f"{tunnel_manager}/set-public-ip/{ip}")
    except Exception:
        return


## Log reader functions
# Constants
MAX_LINES = 750  # Maximum lines to keep in buffer
POLL_INTERVAL = 0.2  # File polling interval in seconds
LOG_MAX_SIZE = 5 * 1024 * 1024   # Rotate log files larger than 5 MB
LOG_KEEP_SIZE = 1 * 1024 * 1024  # Keep the last 1 MB after rotation
LOG_ROTATE_INTERVAL = 30         # Check sizes every N seconds

# State for WebSocket and monitoring
websocket_clients = set()  # Set of connected WebSocket clients
client_tasks = {}  # Client ID to asyncio Task
chronological_log_buffer = deque(maxlen=MAX_LINES)  # Single buffer for all logs in chronological order
file_specific_buffers = {}  # Filename -> Deque (for debugging/specific file views if needed)
file_positions = {}  # Filename -> Last position
file_mtimes = {}    # Filename -> Last modification time
file_inodes = {}    # Filename -> Last inode number

# Per-file terminal emulation state (persists across chunk reads)
class _FileTermState:
    __slots__ = ('lines', 'cursor_row', 'emitted_up_to', 'line_active', 'in_block', 'pending_cr')
    def __init__(self):
        self.lines: list[str] = [""]   # Virtual screen lines
        self.cursor_row: int = 0       # Current cursor row
        self.emitted_up_to: int = 0    # Rows [0..emitted_up_to) already sent as 'append'
        self.line_active: bool = False  # Client has a live span for current partial line
        self.in_block: bool = False    # Cursor-up seen → block mode
        self.pending_cr: bool = False  # \r at end of last chunk (may be start of \r\n)

_file_term_state: dict[str, _FileTermState] = {}
_file_block_sizes: dict[str, int] = {}

# Dedicated task for each client to handle heartbeats and messages
async def client_handler(websocket: WebSocket, client_id: int) -> None:
    """Handle a single client's WebSocket connection"""
    try:
        # Send connection confirmation
        await websocket.send_text(json.dumps({
            "type": "system",
            "html": '<div class="log-system-message" style="color:green;text-align:center;font-style:italic;margin:5px 0;border-bottom:1px dotted #ccc;">Connected to log stream</div>'
        }))

        # Send historical logs from the single chronological buffer
        for line in chronological_log_buffer:
            html_content = ansi_to_html(line)
            await websocket.send_text(json.dumps({"type": "append", "html": html_content}))
        
        # Heartbeat loop
        while True:
            # Process any messages from client (including pings)
            try:
                # Very short timeout to avoid blocking the task
                message = await asyncio.wait_for(websocket.receive_text(), timeout=0.1)
                logger.debug(f"Received message from client {client_id}: {message[:50]}...")
                
                # If it's a ping, send a pong
                if message == "ping":
                    await websocket.send_text("pong")
            except asyncio.TimeoutError:
                # No message received, that's expected
                pass
            
            # Send heartbeat every 10 seconds
            await asyncio.sleep(10)
            try:
                await websocket.send_text("heartbeat")
                logger.debug(f"Sent heartbeat to client {client_id}")
            except Exception as e:
                logger.error(f"Failed to send heartbeat to client {client_id}: {e}")
                # Connection is probably broken, exit the loop
                break
    
    except WebSocketDisconnect:
        logger.info(f"WebSocket client {client_id} disconnected normally")
    except asyncio.CancelledError:
        logger.info(f"Client handler for {client_id} was cancelled")
    except Exception as e:
        logger.error(f"Error in client handler for {client_id}: {e}", exc_info=True)
    finally:
        # Clean up client state
        remove_client(websocket, client_id)

# Remove a client
def remove_client(websocket: WebSocket, client_id: int) -> None:
    """Safely remove a client and cancel its task"""
    if websocket in websocket_clients:
        websocket_clients.remove(websocket)
    
    if client_id in client_tasks:
        client_tasks[client_id].cancel()
        del client_tasks[client_id]
    
    logger.info(f"Client {client_id} removed, remaining clients: {len(websocket_clients)}")

# Get all log files in the directory
async def get_log_files(directory: str) -> List[str]:
    try:
        # Get all log files in the directory
        log_files = [f for f in os.listdir(directory) if f.endswith('.log')]
        
        # Get the full path for each file
        full_paths = [os.path.join(directory, f) for f in log_files]
        
        # Sort files by modification time (oldest first, newest last)
        sorted_paths = sorted(full_paths, key=lambda x: os.path.getmtime(x))
        
        # Extract just the filenames from the sorted paths
        sorted_files = [os.path.basename(path) for path in sorted_paths]
        
        return sorted_files
    except Exception as e:
        logger.error(f"Error listing directory {directory}: {e}")
        return []

# Send message to all connected clients
async def broadcast_message(message: str, msg_type: str = "append", filename: str = "") -> None:
    """Send a formatted log message to all connected clients in parallel"""
    if not websocket_clients:
        return

    html_content = ansi_to_html(message)
    json_msg = json.dumps({"type": msg_type, "html": html_content, "file": filename})

    clients = list(websocket_clients)
    send_tasks = []
    for client in clients:
        task = asyncio.create_task(send_to_client(client, json_msg))
        send_tasks.append(task)

    results = await asyncio.gather(*send_tasks, return_exceptions=True)

    disconnected_clients = set()
    for client, result in zip(clients, results):
        if isinstance(result, Exception):
            logger.error(f"Error sending to client {id(client)}: {result}")
            disconnected_clients.add(client)

    websocket_clients.difference_update(disconnected_clients)

async def send_to_client(client: WebSocket, content: str) -> bool:
    """Helper function to send content to a single client"""
    await client.send_text(content)
    return True

# Tail a single log file
async def tail_log_file(filepath: str) -> None:
    """Monitor a log file for changes and broadcast new content"""
    filename = os.path.basename(filepath)

    try:
        if not os.path.exists(filepath):
            return

        stat = os.stat(filepath)
        current_size = stat.st_size
        current_mtime = stat.st_mtime
        current_inode = stat.st_ino
        last_position = file_positions.get(filename, None)
        last_mtime = file_mtimes.get(filename, 0)
        last_inode = file_inodes.get(filename, None)

        # Detect file replacement (new inode = mv + recreate)
        replaced = last_inode is not None and current_inode != last_inode

        # First time seeing this file
        if last_position is None:
            logger.info(f"New file: {filename}, size={current_size}")
            file_specific_buffers[filename] = deque(maxlen=MAX_LINES)

            async with aiofiles.open(filepath, 'rb') as file:
                raw = await file.read()

            text = raw.decode('utf-8', errors='replace')
            # For initial read, only keep last MAX_LINES lines
            lines = text.split('\n')
            if len(lines) > MAX_LINES:
                lines = lines[-MAX_LINES:]
                text = '\n'.join(lines)

            await _process_chunk(text, filename)

            file_positions[filename] = current_size
            file_mtimes[filename] = current_mtime
            file_inodes[filename] = current_inode

        # File replaced (different inode) or modified since last check
        elif replaced or current_mtime > last_mtime or current_size != last_position:
            if replaced:
                logger.info(f"File {filename} was replaced (new inode)")
                last_position = 0
                _file_term_state.pop(filename, None)
                _file_block_sizes.pop(filename, None)
            elif current_size < last_position:
                logger.info(f"File {filename} was truncated")
                last_position = 0
                _file_term_state.pop(filename, None)
                _file_block_sizes.pop(filename, None)
            else:
                logger.debug(f"File {filename} changed: size={current_size}, last_pos={last_position}")

            async with aiofiles.open(filepath, 'rb') as file:
                if last_position > 0:
                    await file.seek(last_position)
                raw = await file.read()

            text = raw.decode('utf-8', errors='replace')
            await _process_chunk(text, filename)

            file_positions[filename] = current_size
            file_mtimes[filename] = current_mtime
            file_inodes[filename] = current_inode

    except Exception as e:
        logger.error(f"Error tailing {filepath}: {e}")


async def _process_chunk(text: str, filename: str) -> None:
    """Process a chunk of text with terminal-like \\r, \\n, and cursor-up handling.

    Maintains per-file state across calls so partial lines are not flushed
    prematurely.  Supports \\x1b[A (cursor up) for nested progress bars (tqdm).

    Lines are kept between chunks so cursor-up in a later chunk can reference
    lines written in an earlier chunk.
    """
    state = _file_term_state.get(filename)
    if state is None:
        state = _FileTermState()
        _file_term_state[filename] = state

    # If previous chunk ended with \r, prepend it so the split sees it
    if state.pending_cr:
        text = '\r' + text
        state.pending_cr = False

    parts = _CHUNK_TOKEN_RE.split(text)

    had_cursor_up = False
    for i, part in enumerate(parts):
        if not part:
            continue

        if part == '\r\n' or part == '\n':
            # Line complete — advance cursor
            state.cursor_row += 1
            if state.cursor_row >= len(state.lines):
                state.lines.append("")
            elif state.in_block:
                # In block mode (cursor-up active), the next line is about
                # to be rewritten.  Clear it so new text replaces old
                # content instead of appending to it.
                state.lines[state.cursor_row] = ""
        elif part == '\r':
            # Peek ahead: if next non-empty part is \n or \r\n, this \r
            # is just part of a line ending (PTY onlcr artifact), not an
            # overwrite.  Only clear the line for lone \r (progress bars).
            next_part = None
            for j in range(i + 1, len(parts)):
                if parts[j]:
                    next_part = parts[j]
                    break
            if next_part in ('\n', '\r\n'):
                pass  # skip — the following \n/\r\n will commit the line
            elif next_part is None:
                # \r at end of chunk — may be start of \r\n split across reads
                state.pending_cr = True
            else:
                state.lines[state.cursor_row] = ""
        elif part.startswith('\x1b['):
            # CSI sequence
            body = part[2:]
            letter = body[-1]
            param_str = body[:-1]
            # Strip DEC private-mode prefix (e.g. \x1b[?25l)
            if param_str.startswith('?'):
                pass  # ignore show/hide cursor, etc.
            elif letter == 'A' or letter == 'F':
                # Cursor up (A) / Cursor previous line (F)
                try:
                    n = int(param_str) if param_str else 1
                except ValueError:
                    n = 1
                n = min(n, 500)
                state.cursor_row = max(0, state.cursor_row - n)
                state.in_block = True
                had_cursor_up = True
            elif letter == 'B' or letter == 'E':
                # Cursor down (B) / Cursor next line (E)
                try:
                    n = int(param_str) if param_str else 1
                except ValueError:
                    n = 1
                n = min(n, 500)
                state.cursor_row += n
                while state.cursor_row >= len(state.lines):
                    state.lines.append("")
            elif letter == 'G':
                # Cursor horizontal absolute — move to column N.
                # We don't track columns; treat as \r (column 1).
                state.lines[state.cursor_row] = ""
            elif letter == 'K':
                # Erase in line: 0/default = cursor→end, 1 = start→cursor,
                # 2 = entire line.  Without column tracking, only param 2
                # (entire line) can be handled correctly.  Param 0/1 are
                # no-ops — the line was already cleared by \r or \x1b[G
                # before new text was written, so there is nothing beyond
                # the cursor to erase.
                try:
                    p = int(param_str) if param_str else 0
                except ValueError:
                    p = 0
                if p == 2:
                    state.lines[state.cursor_row] = ""
            elif letter == 'J':
                # Erase in display — clear visible lines below cursor
                try:
                    p = int(param_str) if param_str else 0
                except ValueError:
                    p = 0
                if p in (0, 2):
                    for r in range(state.cursor_row, len(state.lines)):
                        state.lines[r] = ""
            elif letter == 'm':
                # SGR (color/style) — preserve in line content
                state.lines[state.cursor_row] += part
            # Other CSI (cursor show/hide, etc.): ignore
        else:
            # Plain text — append to current line
            state.lines[state.cursor_row] += part

    # --- Emission ---
    if state.in_block:
        if had_cursor_up:
            # Still actively using cursor-up: emit all lines as a block
            await _emit_block(filename, state.lines)
        else:
            # No cursor-up this chunk — progress bars finished, transition
            # back to line mode.  Flush remaining block lines as appends.
            await _emit_block(filename, state.lines)
            state.in_block = False
            state.emitted_up_to = state.cursor_row
            state.line_active = False
            _file_block_sizes.pop(filename, None)

        # Trim old lines in block mode to prevent unbounded growth.
        # Keep a window around the cursor so cursor-up still works.
        if len(state.lines) > 400:
            # Keep the last 200 lines (enough for any progress bar block)
            keep = 200
            trim = len(state.lines) - keep
            state.lines = state.lines[trim:]
            state.cursor_row = max(0, state.cursor_row - trim)
            state.emitted_up_to = max(0, state.emitted_up_to - trim)
    else:
        # Single-line mode — backward compatible
        # Emit newly completed lines (emitted_up_to .. cursor_row)
        for i in range(state.emitted_up_to, state.cursor_row):
            line = state.lines[i] if i < len(state.lines) else ""
            if line or state.line_active:
                if i == state.emitted_up_to and state.line_active:
                    # First completed line overwrites the partial preview
                    await _emit_line(filename, line, "overwrite")
                elif line:
                    await _emit_line(filename, line, "append")
                state.line_active = False
        state.emitted_up_to = state.cursor_row

        # Preview current (incomplete) line
        current = state.lines[state.cursor_row] if state.cursor_row < len(state.lines) else ""
        if current:
            msg_type = "overwrite" if state.line_active else "append"
            await _emit_line(filename, current, msg_type)
            state.line_active = True

        # Trim old completed lines to prevent unbounded growth
        if state.emitted_up_to > 200:
            trim = state.emitted_up_to
            state.lines = state.lines[trim:]
            state.cursor_row -= trim
            state.emitted_up_to = 0


async def _emit_line(filename: str, text: str, msg_type: str) -> None:
    """Store a line in buffers and broadcast to clients.

    "overwrite" messages update the per-file buffer and are broadcast live
    to connected clients, but are NOT stored in the chronological buffer.
    This prevents hundreds of intermediate progress-bar states from stacking
    up when multiple log files are active and interleaving writes.
    When the line completes it is emitted as "append" and stored normally.
    """
    if msg_type == "overwrite":
        # Replace last entry in file-specific buffer
        buf = file_specific_buffers.get(filename)
        if buf:
            buf[-1] = text
        else:
            file_specific_buffers.setdefault(filename, deque(maxlen=MAX_LINES)).append(text)
        # Skip chronological buffer — live clients get the broadcast,
        # new clients will see the final state when it becomes an "append".
    else:
        file_specific_buffers.setdefault(filename, deque(maxlen=MAX_LINES)).append(text)
        chronological_log_buffer.append(text)

    await broadcast_message(text, msg_type, filename)


async def _emit_block(filename: str, lines: list[str]) -> None:
    """Store and broadcast a multi-line progress block."""
    html_lines = [ansi_to_html(line) for line in lines]
    if not any(lines):
        return

    new_size = len(lines)

    # Replace previous block entries in file-specific buffer
    prev_size = _file_block_sizes.get(filename, 0)
    buf = file_specific_buffers.get(filename)
    if buf is not None:
        for _ in range(min(prev_size, len(buf))):
            buf.pop()
    else:
        buf = deque(maxlen=MAX_LINES)
        file_specific_buffers[filename] = buf
    for line in lines:
        buf.append(line or "")

    # Skip chronological buffer for block updates — live clients get the
    # broadcast, new clients see the final state when block mode ends.

    _file_block_sizes[filename] = new_size

    json_msg = json.dumps({
        "type": "overwrite_block",
        "lines": html_lines,
        "file": filename
    })

    clients = list(websocket_clients)
    if not clients:
        return
    send_tasks = [asyncio.create_task(send_to_client(c, json_msg)) for c in clients]
    results = await asyncio.gather(*send_tasks, return_exceptions=True)
    disconnected = {c for c, r in zip(clients, results) if isinstance(r, Exception)}
    websocket_clients.difference_update(disconnected)


def _rotate_single_file(filepath: str) -> None:
    """Truncate a single log file, keeping the last LOG_KEEP_SIZE bytes.

    Atomically replaces the file via write-to-temp + rename so readers
    see a clean inode change and re-read from the start.
    """
    size = os.path.getsize(filepath)
    if size <= LOG_MAX_SIZE:
        return
    logger.info(f"Rotating {filepath}: {size / 1024 / 1024:.1f} MB > {LOG_MAX_SIZE / 1024 / 1024:.0f} MB limit")
    with open(filepath, "rb") as f:
        f.seek(max(0, size - LOG_KEEP_SIZE))
        tail = f.read()
    # Skip a partial first line
    nl = tail.find(b"\n")
    if nl >= 0:
        tail = tail[nl + 1:]
    tmp = filepath + ".rotate"
    with open(tmp, "wb") as f:
        f.write(tail)
    os.replace(tmp, filepath)
    logger.info(f"Rotated {filepath}: kept {len(tail)} bytes")


def _rotate_log_file(filepath: str) -> None:
    """Rotate a portal log file and its corresponding clean log in /var/log/.

    The provisioner logging creates paired files:
      /var/log/portal/X.log  (raw ANSI for the portal)
      /var/log/X.log          (clean text for external logging)
    Both are rotated together to keep disk usage bounded.

    After rotation, updates the file tracking state so tail_log_file
    doesn't re-read the kept tail as new data.
    """
    try:
        _rotate_single_file(filepath)
        # Update tracking so we don't re-read the kept tail
        filename = os.path.basename(filepath)
        stat = os.stat(filepath)
        file_positions[filename] = stat.st_size
        file_mtimes[filename] = stat.st_mtime
        file_inodes[filename] = stat.st_ino
        # Also rotate the companion clean log (e.g. /var/log/portal/X.log → /var/log/X.log)
        directory, basename = os.path.split(filepath)
        if os.path.basename(directory) == "portal":
            clean_path = os.path.join(os.path.dirname(directory), basename)
            if os.path.exists(clean_path):
                _rotate_single_file(clean_path)
    except Exception as e:
        logger.error(f"Failed to rotate {filepath}: {e}")


# Main monitoring loop
async def monitor_log_directory(directory: str) -> None:
    """Main task to monitor log directory and tail files"""
    logger.info(f"Starting log monitoring in {directory}")
    last_rotate_check = 0.0

    while True:
        try:
            # Get current log files
            log_files = await get_log_files(directory)

            # Monitor each file
            for log_file in log_files:
                filepath = os.path.join(directory, log_file)
                await tail_log_file(filepath)

            # Clean up deleted files
            for filename in list(file_positions.keys()):
                if filename not in log_files:
                    logger.info(f"File {filename} was removed, cleaning up")
                    file_positions.pop(filename, None)
                    file_mtimes.pop(filename, None)
                    file_inodes.pop(filename, None)
                    file_specific_buffers.pop(filename, None)
                    _file_term_state.pop(filename, None)
                    _file_block_sizes.pop(filename, None)

            # Periodically check log file sizes and rotate if needed
            now = asyncio.get_event_loop().time()
            if now - last_rotate_check > LOG_ROTATE_INTERVAL:
                last_rotate_check = now
                for log_file in log_files:
                    _rotate_log_file(os.path.join(directory, log_file))

            # Small delay before next poll
            await asyncio.sleep(POLL_INTERVAL)

        except asyncio.CancelledError:
            logger.info("Monitor task cancelled")
            break
        except Exception as e:
            logger.error(f"Error in monitor_log_directory: {e}")
            await asyncio.sleep(1)

# WebSocket connection handler
async def websocket_logs(websocket: WebSocket) -> None:
    """Handle a new WebSocket connection"""
    await websocket.accept()
    
    # Generate client ID and add to clients list
    client_id = id(websocket)
    websocket_clients.add(websocket)
    logger.info(f"WebSocket client {client_id} connected, total clients: {len(websocket_clients)}")
    
    # Create a dedicated task for this client
    client_task = asyncio.create_task(client_handler(websocket, client_id))
    client_tasks[client_id] = client_task
    
    try:
        # Wait for the client handler to complete
        await client_task
    except asyncio.CancelledError:
        # Expected when client disconnects, no need to log as error
        logger.debug(f"WebSocket client {client_id} disconnected")
    except Exception as e:
        logger.error(f"Error in main websocket handler for client {client_id}: {e}")
    finally:
        # Ensure client is removed
        remove_client(websocket, client_id)

@app.websocket("/ws-logs")
async def logs_websocket(websocket: WebSocket) -> None:
    await websocket_logs(websocket)

@app.get("/download-logs")
async def download_logs(filename: str = None) -> StreamingResponse:
    """
    Zip the /var/log directory and serve it as a downloadable file.
    
    Parameters:
    - filename: Optional custom filename for the zip file
    """
    try:
        # Create a memory buffer to store the zip file
        zip_buffer = io.BytesIO()
        
        # Define the directory to zip
        log_dir = "/var/log"
        
        # Check if the directory exists
        if not os.path.exists(log_dir):
            raise HTTPException(status_code=404, detail="Log directory not found")
        
        # Use provided filename or generate one with timestamp
        if not filename:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            zip_filename = f"logs_{timestamp}.zip"
        else:
            # Ensure the filename ends with .zip
            zip_filename = filename if filename.endswith('.zip') else f"{filename}.zip"
        
        # Create a zip file in the memory buffer
        with zipfile.ZipFile(zip_buffer, 'w', zipfile.ZIP_DEFLATED) as zipf:
            # Walk through the directory and add all files to the zip
            for root, dirs, files in os.walk(log_dir):
                for file in files:
                    file_path = os.path.join(root, file)
                    # Calculate the relative path for the file inside the zip
                    relative_path = os.path.relpath(file_path, os.path.dirname(log_dir))
                    try:
                        zipf.write(file_path, relative_path)
                    except (PermissionError, zipfile.LargeZipFile, OSError) as e:
                        # Skip files that can't be accessed or are too large
                        continue
        
        # Reset the buffer position to the beginning
        zip_buffer.seek(0)
        
        # Return the zip file as a downloadable response
        return StreamingResponse(
            zip_buffer,
            media_type="application/zip",
            headers={"Content-Disposition": f'attachment; filename="{os.path.basename(zip_filename).replace(chr(34), "_")}"'}
        )
    
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error creating zip file: {str(e)}")

def _is_finite_num(value) -> bool:
    """True only for real, finite numbers (excludes bool, NaN and +/-Inf)."""
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)


def _json_safe(obj):
    """Recursively replace non-finite floats (NaN/Inf) with None.

    Backstop so a single unreadable nvidia-smi field can never 500 the metrics
    endpoint: Starlette's JSONResponse encodes with allow_nan=False and raises
    on NaN/Inf. GPUtil produces NaN for any field it fails to parse, not just
    memory, so sanitize the whole structure rather than individual fields.
    """
    if isinstance(obj, float):
        return obj if math.isfinite(obj) else None
    if isinstance(obj, dict):
        return {k: _json_safe(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_json_safe(v) for v in obj]
    return obj


async def _collect_metrics() -> dict:
    """Collect system metrics. Shared by the route and the manifest."""
    # Try to get container memory metrics first
    container_memory = get_container_memory_stats()
    
    # Initialize metrics dictionary with memory info
    metrics = {
        'ram': container_memory if container_memory else {
            'total': psutil.virtual_memory().total,
            'used': psutil.virtual_memory().used,
            'percent': psutil.virtual_memory().percent
        },
        'disk': {
            'total': psutil.disk_usage('/').total,
            'used': psutil.disk_usage('/').used,
            'percent': psutil.disk_usage('/').percent
        }
    }
    
    # Add container detection info
    metrics['environment'] = 'container' if is_in_container() else 'host'

    # CPU metrics
    metrics['cpu'] = get_cpu_stats()

    # Workspace volume (only if mounted as a separate filesystem)
    volume_info = get_workspace_volume_info()
    if volume_info:
        metrics['volume'] = volume_info
    
    # Get GPU metrics from both NVIDIA and AMD sources
    all_gpus = []
    nvidia_error = None
    rocm_error = None
    
    # Try to get NVIDIA GPUs (offloaded — GPUtil shells out to nvidia-smi, blocking)
    try:
        nvidia_gpus = await asyncio.to_thread(GPUtil.getGPUs)
        all_gpus.extend(nvidia_gpus)
    except Exception as e:
        nvidia_error = str(e)

    # Try to get ROCm GPUs (offloaded — get_rocm_gpus shells out to rocm-smi, blocking)
    try:
        rocm_gpus = await asyncio.to_thread(get_rocm_gpus)
        all_gpus.extend(rocm_gpus)
    except Exception as e:
        rocm_error = str(e)
        
    # Calculate metrics if any GPUs are found
    if all_gpus:
        # GPUtil casts any nvidia-smi field it cannot parse to float('nan').
        # The GB10 (DGX Spark) has no dedicated framebuffer, so it reports
        # memory.total and memory.used as "[N/A]" (a MIG-enabled parent device
        # does too); those arrive here as NaN. Filter out non-finite values:
        # they would otherwise propagate into the response and crash Starlette's
        # JSONResponse (which encodes with allow_nan=False).
        loads = [g.load for g in all_gpus if _is_finite_num(g.load)]
        avg_load = sum(loads) / len(loads) if loads else 0.0

        # Sum total and used memory across all GPUs
        # Handle potential unit differences between NVIDIA and ROCm
        total_memory = 0.0
        used_memory = 0.0
        memory_available = False

        for gpu in all_gpus:
            # For ROCm GPUs, memoryTotal might be in bytes, while NVIDIA is in MB
            if hasattr(gpu, 'memoryTotal_mb'):
                # Use the MB values directly if available
                gpu_total, gpu_used = gpu.memoryTotal_mb, gpu.memoryUsed_mb
            else:
                # Assume standard GPUtil format which is already in MB
                gpu_total, gpu_used = gpu.memoryTotal, gpu.memoryUsed
            # Only count GPUs that actually report memory; preserves valid data
            # in mixed fleets where some GPUs report and others don't.
            if _is_finite_num(gpu_total) and _is_finite_num(gpu_used):
                total_memory += gpu_total
                used_memory += gpu_used
                memory_available = True

        # Calculate overall memory usage percentage
        memory_percent = (used_memory / total_memory * 100) if total_memory > 0 else 0

        metrics['gpu'] = {
            'count': len(all_gpus),
            'avg_load_percent': float(avg_load * 100),  # Convert to percentage
            # None (not 0) when memory is unreported, so the UI can tell the
            # difference between "0 MB used" and "not available".
            'memory_used': float(used_memory) if memory_available else None,
            'memory_total': float(total_memory) if memory_available else None,
            'memory_percent': float(memory_percent) if memory_available else None,
            'memory_unit': 'MB'  # Add unit for clarity
        }
        
        # Add GPU details by type
        nvidia_count = len([gpu for gpu in all_gpus if hasattr(gpu, 'id') and not isinstance(gpu.id, str)])
        rocm_count = len(all_gpus) - nvidia_count
        
        if nvidia_count > 0:
            metrics['gpu']['nvidia_count'] = nvidia_count
        if rocm_count > 0:
            metrics['gpu']['amd_count'] = rocm_count
            
    else:
        metrics['gpu'] = {
            'count': 0,
            'avg_load_percent': 0,
            'memory_used': 0,
            'memory_total': 0,
            'memory_percent': 0,
            'memory_unit': 'MB'  # Keep consistent unit notation
        }
        
        # Add error information if applicable
        errors = {}
        if nvidia_error:
            errors['nvidia'] = nvidia_error
        if rocm_error:
            errors['rocm'] = rocm_error
            
        if errors:
            metrics['gpu']['errors'] = errors

    return _json_safe(metrics)


@app.get("/system-metrics")
async def get_system_metrics() -> JSONResponse:
    return JSONResponse(content=await _collect_metrics())


# --------------------------------------------------------------------------- #
# Capability discovery — agent-facing manifest, OpenAI-endpoint rollup, and   #
# runtime provisioning. The assembly logic lives in the `capabilities`        #
# package; these routes just collect live data and hand it over.              #
# --------------------------------------------------------------------------- #

async def _build_capabilities(include: set[str]) -> dict:
    # Supervisor states are already offloaded. The GPU summary and manifest
    # assembly run blocking subprocesses (nvidia-smi via GPUtil, ldconfig/nvidia-smi
    # inside assemble_live, each timeout=5), so offload them too — otherwise a single
    # /capabilities call stalls the event loop and the live pollers. metrics are opt-in.
    try:
        processes = await _collect_supervisor()
    except Exception as e:
        logger.warning(f"capabilities: supervisor unavailable: {e}")
        processes = []
    metrics = await _collect_metrics() if "metrics" in include else None
    gpu = await asyncio.to_thread(get_gpu_info)
    return await asyncio.to_thread(
        assemble_live,
        processes=processes,
        metrics=metrics,
        gpu=gpu,
        include=include,
    )


def _parse_include(include: Optional[str]) -> set[str]:
    if not include:
        return set()
    return {p.strip() for p in include.split(",") if p.strip()}


@app.get("/capabilities", summary="Machine-readable capability manifest")
async def get_capabilities(include: Optional[str] = None) -> JSONResponse:
    """Full instance manifest for AI agents.

    Pass `?include=metrics,packages` to add live CPU/GPU/RAM metrics and probed
    package versions (both omitted by default to keep the response fast).
    """
    return JSONResponse(await _build_capabilities(_parse_include(include)))


@app.get("/.well-known/vast-capabilities", include_in_schema=False)
async def get_capabilities_well_known(include: Optional[str] = None) -> JSONResponse:
    return JSONResponse(await _build_capabilities(_parse_include(include)))


@app.get(
    "/capabilities/services",
    response_model=List[ServiceInfo],
    summary="Running/known services with reachable URLs",
)
async def get_capabilities_services():
    manifest = await _build_capabilities(set())
    # Return the plain list so FastAPI validates/serialises via response_model
    # and the OpenAPI schema matches actual output.
    return manifest.get("services", [])


@app.get(
    "/capabilities/endpoints",
    response_model=List[OpenAIEndpoint],
    summary="OpenAI /v1 endpoints exposed by running services",
)
async def get_capabilities_endpoints():
    manifest = await _build_capabilities(set())
    return manifest.get("endpoints_openai", [])


@app.post(
    "/capabilities/provision",
    response_model=ProvisionResponse,
    summary="Install more dependencies via the provisioner",
)
async def post_capabilities_provision(req: ProvisionRequest):
    """Launch the declarative provisioner in the background.

    Accepts a manifest URL, inline YAML, or simple pip/git/download lists.
    Returns immediately; follow progress in /var/log/portal/provisioning.log.

    SECURITY: this installs/runs caller-supplied code (pip/git/post_commands), so
    it is an install+exec surface. It is gated by the Caddy token edge for remote
    callers and, like the other /supervisor/* control routes, is unauthenticated
    only on localhost inside the (single-tenant) container.
    """
    log_file = "/var/log/portal/provisioning.log"
    cmd: list[str] = ["/opt/instance-tools/bin/provisioner"]
    cleanup_path: Optional[str] = None

    if req.manifest_url:
        cmd.append(req.manifest_url)
    elif req.inline_yaml:
        # Materialise inline YAML to a temp file the provisioner can read.
        import tempfile
        fd, cleanup_path = tempfile.mkstemp(suffix=".yaml", prefix="provision-")
        with os.fdopen(fd, "w") as f:
            f.write(req.inline_yaml)
        cmd.append(cleanup_path)
    else:
        # Build a minimal manifest from the simple lists.
        manifest: dict = {"version": 1}
        if req.pip:
            manifest["pip_packages"] = [{"packages": req.pip}]
        if req.git_repos:
            manifest["git_repos"] = [{"url": u} for u in req.git_repos]
        if req.downloads:
            manifest["downloads"] = [{"url": u} for u in req.downloads]
        if len(manifest) == 1:
            raise HTTPException(
                status_code=400,
                detail="Provide one of: manifest_url, inline_yaml, pip, git_repos, downloads",
            )
        import tempfile
        fd, cleanup_path = tempfile.mkstemp(suffix=".yaml", prefix="provision-")
        with os.fdopen(fd, "w") as f:
            yaml.safe_dump(manifest, f)
        cmd.append(cleanup_path)

    try:
        # Detached so it outlives this request (same pattern as the restart route).
        if cleanup_path:
            # The provisioner reads the temp manifest asynchronously, so it can't
            # be deleted inline. Launch a small detached Python wrapper (no shell)
            # that runs the provisioner and removes the temp file when it exits.
            wrapper = (
                "import os, subprocess, sys\n"
                "subprocess.run(sys.argv[1:3])\n"
                "try:\n"
                "    os.unlink(sys.argv[3])\n"
                "except OSError:\n"
                "    pass\n"
            )
            subprocess.Popen(
                [sys.executable, "-c", wrapper, cmd[0], cmd[1], cleanup_path],
                start_new_session=True,
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            )
        else:
            subprocess.Popen(
                cmd, start_new_session=True,
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            )
    except Exception as e:
        if cleanup_path and os.path.isfile(cleanup_path):
            os.unlink(cleanup_path)
        logger.error(f"Failed to launch provisioner: {e}")
        raise HTTPException(status_code=500, detail="Failed to launch provisioner")

    return {
        "status": "started",
        "detail": "Provisioner launched in the background",
        "log_file": log_file,
    }

